<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/category' => [
            [['_route' => 'app_category_index', '_controller' => 'App\\Controller\\CategoryController::index'], null, ['GET' => 0], null, true, false, null],
            [['_route' => 'category_index', '_controller' => 'App\\Controller\\CategoryController::index'], null, null, null, false, false, null],
        ],
        '/category/new' => [[['_route' => 'app_category_new', '_controller' => 'App\\Controller\\CategoryController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/director' => [
            [['_route' => 'app_director_index', '_controller' => 'App\\Controller\\DirectorController::index'], null, ['GET' => 0], null, true, false, null],
            [['_route' => 'director_index', '_controller' => 'App\\Controller\\DirectorController::index'], null, null, null, false, false, null],
        ],
        '/director/new' => [[['_route' => 'app_director_new', '_controller' => 'App\\Controller\\DirectorController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/home' => [
            [['_route' => 'app_home', '_controller' => 'App\\Controller\\HomeController::index'], null, null, null, false, false, null],
            [['_route' => 'home', '_controller' => 'App\\Controller\\HomeController::index'], null, null, null, false, false, null],
            [['_route' => 'admin_login', '_controller' => 'App\\Controller\\LoginController::admin_login'], null, ['GET' => 0], null, false, false, null],
        ],
        '/userhome' => [
            [['_route' => 'app_userhome', '_controller' => 'App\\Controller\\HomeController::userindex'], null, null, null, false, false, null],
            [['_route' => 'user_login', '_controller' => 'App\\Controller\\LoginController::user_login'], null, ['GET' => 0], null, false, false, null],
            [['_route' => 'user_home', '_controller' => 'App\\Controller\\MoviesController::userHome'], null, null, null, false, false, null],
        ],
        '/' => [[['_route' => 'app_login', '_controller' => 'App\\Controller\\LoginController::index'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/admin_login' => [[['_route' => 'admin', '_controller' => 'App\\Controller\\LoginController::admin_login'], null, null, null, false, false, null]],
        '/movieinfo' => [[['_route' => 'app_movieinfo_index', '_controller' => 'App\\Controller\\MovieinfoController::index'], null, ['GET' => 0], null, true, false, null]],
        '/movieinfo/new' => [[['_route' => 'app_movieinfo_new', '_controller' => 'App\\Controller\\MovieinfoController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/movielist' => [[['_route' => 'app_movielist', '_controller' => 'App\\Controller\\MovielistController::index'], null, null, null, false, false, null]],
        '/movies' => [
            [['_route' => 'app_movies_index', '_controller' => 'App\\Controller\\MoviesController::index'], null, ['GET' => 0], null, true, false, null],
            [['_route' => 'movie_index', '_controller' => 'App\\Controller\\MoviesController::index'], null, null, null, false, false, null],
        ],
        '/movies/new' => [[['_route' => 'app_movies_new', '_controller' => 'App\\Controller\\MoviesController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/logout' => [[['_route' => 'logout'], null, null, null, false, false, null]],
        '/register' => [[['_route' => 'register', '_controller' => 'App\\Controller\\SignUpController::register'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/category/([^/]++)(?'
                    .'|(*:28)'
                    .'|/edit(*:40)'
                    .'|(*:47)'
                .')'
                .'|/director/([^/]++)(?'
                    .'|(*:76)'
                    .'|/edit(*:88)'
                    .'|(*:95)'
                .')'
                .'|/movie(?'
                    .'|info/([^/]++)(?'
                        .'|(*:128)'
                        .'|/edit(*:141)'
                        .'|(*:149)'
                    .')'
                    .'|s/([^/]++)(?'
                        .'|(*:171)'
                        .'|/edit(*:184)'
                        .'|(*:192)'
                    .')'
                .')'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        28 => [[['_route' => 'app_category_show', '_controller' => 'App\\Controller\\CategoryController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        40 => [[['_route' => 'app_category_edit', '_controller' => 'App\\Controller\\CategoryController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        47 => [[['_route' => 'app_category_delete', '_controller' => 'App\\Controller\\CategoryController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        76 => [[['_route' => 'app_director_show', '_controller' => 'App\\Controller\\DirectorController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        88 => [[['_route' => 'app_director_edit', '_controller' => 'App\\Controller\\DirectorController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        95 => [[['_route' => 'app_director_delete', '_controller' => 'App\\Controller\\DirectorController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        128 => [[['_route' => 'app_movieinfo_show', '_controller' => 'App\\Controller\\MovieinfoController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        141 => [[['_route' => 'app_movieinfo_edit', '_controller' => 'App\\Controller\\MovieinfoController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        149 => [[['_route' => 'app_movieinfo_delete', '_controller' => 'App\\Controller\\MovieinfoController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        171 => [[['_route' => 'app_movies_show', '_controller' => 'App\\Controller\\MoviesController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        184 => [[['_route' => 'app_movies_edit', '_controller' => 'App\\Controller\\MoviesController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        192 => [
            [['_route' => 'app_movies_delete', '_controller' => 'App\\Controller\\MoviesController::delete'], ['id'], ['POST' => 0], null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
