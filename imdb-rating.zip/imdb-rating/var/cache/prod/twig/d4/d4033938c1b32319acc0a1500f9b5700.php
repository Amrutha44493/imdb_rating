<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* userhome/index.html.twig */
class __TwigTemplate_e9ae0db77835e1e324fc838feef36a00 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "
<!-- nav_menu.html.twig -->
<link rel=\"stylesheet\" href=\"";
        // line 3
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/css/style.css"), "html", null, true);
        echo "\">
<link rel=\"stylesheet\" href=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/css/style.css"), "html", null, true);
        echo "\">
<center>
<nav>

    <ul class=\"nav\">
        <li><a href=\"";
        // line 9
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("home");
        echo "\">Home</a></li>
        <li><a href=\"#\">Update Profile</a></li>
        <li><a href=\"";
        // line 11
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("logout");
        echo "\">Logout</a></li>
        <center>
    </ul>
</nav>
<br><br><center><b>WELCOME DASHBOARD!!!<b></center>


";
        // line 18
        $this->displayBlock('body', $context, $blocks);
    }

    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 19
        echo "     <h1>Movie List</h1>
    <div class=\"movie-list\">
        ";
        // line 21
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["movies"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["movie"]) {
            // line 22
            echo "            <div class=\"movie\">
                <h2>";
            // line 23
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["movie"], "title", [], "any", false, false, false, 23), "html", null, true);
            echo "</h2>
                <p>Description: ";
            // line 24
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["movie"], "description", [], "any", false, false, false, 24), "html", null, true);
            echo "</p>
                <img src=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(("movie_images_directory/" . twig_get_attribute($this->env, $this->source, $context["movie"], "image", [], "any", false, false, false, 25))), "html", null, true);
            echo "\" alt=\"Movie Poster\">
                ";
            // line 26
            if (twig_get_attribute($this->env, $this->source, $context["movie"], "video", [], "any", false, false, false, 26)) {
                // line 27
                echo "                    <video controls>
                        <source src=\"";
                // line 28
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(("path_to_video_directory/" . twig_get_attribute($this->env, $this->source, $context["movie"], "video", [], "any", false, false, false, 28))), "html", null, true);
                echo "\" type=\"video/mp4\">
                        Your browser does not support the video tag.
                    </video>
                ";
            }
            // line 32
            echo "                <!-- Add more details as needed -->
            </div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['movie'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 35
        echo "    </div>
";
    }

    public function getTemplateName()
    {
        return "userhome/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  119 => 35,  111 => 32,  104 => 28,  101 => 27,  99 => 26,  95 => 25,  91 => 24,  87 => 23,  84 => 22,  80 => 21,  76 => 19,  69 => 18,  59 => 11,  54 => 9,  46 => 4,  42 => 3,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "userhome/index.html.twig", "/home/amrutha/imdb-rating/templates/userhome/index.html.twig");
    }
}
